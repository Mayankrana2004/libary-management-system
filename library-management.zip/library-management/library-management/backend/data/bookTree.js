const AVLTree = require("../structures/avlTree");
module.exports = new AVLTree();
