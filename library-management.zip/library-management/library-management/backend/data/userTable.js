const HashTable = require("../structures/hashTable");
module.exports = new HashTable();
